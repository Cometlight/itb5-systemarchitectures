package pimpmypipe.filter;

import pimpmypipe.interfaces.Readable;

public abstract class Sink<T> implements Readable<T>, Runnable{

    public void run() {
            
    }
    
    
}
